﻿namespace Empires.Contracts
{
    public interface IDestroyable
    {
        // Added public setter
        int Health { get; set; }
    }
}
