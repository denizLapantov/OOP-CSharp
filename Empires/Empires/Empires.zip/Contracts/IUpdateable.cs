﻿namespace Empires.Contracts
{
    public interface IUpdateable
    {
        void Update();
    }
}
