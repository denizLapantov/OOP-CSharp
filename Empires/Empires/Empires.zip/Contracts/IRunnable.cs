﻿namespace Empires.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
