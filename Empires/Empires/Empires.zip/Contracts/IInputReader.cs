﻿namespace Empires.Contracts
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
